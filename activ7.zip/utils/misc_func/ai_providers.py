"""
Улучшенный модуль для работы с различными AI провайдерами
Поддерживает OpenAI, Anthropic, Google Gemini, Pollinations, и другие провайдеры
Включает продвинутые возможности управления параметрами генерации
"""
import random
import asyncio
from datetime import datetime
import re
import aiohttp
import urllib.parse
import json
from loguru import logger
from dotenv import load_dotenv
from data.config import PROMPT_TEMPLATE, DETAILS, TIMEOUT
from loader import db
import os
load_dotenv()

class AIProvider:
    """Базовый класс для AI провайдеров"""
    
    def __init__(self, api_key: str = None, timeout: int = 30):
        self.api_key = api_key
        self.timeout = timeout
    
    async def generate_dialog(self, prompt: str, model: str = None, system_prompt: str = None) -> str:
        """Генерирует диалог через AI API"""
        raise NotImplementedError

class OpenAIProvider(AIProvider):
    """Провайдер для OpenAI API"""
    
    def __init__(self, api_key: str, timeout: int = 30):
        super().__init__(api_key, timeout)
        self.base_url = "https://api.openai.com/v1"
    
    async def generate_dialog(self, prompt: str, model: str = "gpt-4o-mini", system_prompt: str = None) -> str:
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        payload = {
            "model": model,
            "messages": messages,
            "max_tokens": 2000,
            "temperature": 0.8
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{self.base_url}/chat/completions",
                headers=headers,
                json=payload,
                timeout=self.timeout
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise Exception(f"OpenAI API error {response.status}: {error_text}")
                
                data = await response.json()
                return data["choices"][0]["message"]["content"]

class AnthropicProvider(AIProvider):
    """Провайдер для Anthropic Claude API"""
    
    def __init__(self, api_key: str, timeout: int = 30):
        super().__init__(api_key, timeout)
        self.base_url = "https://api.anthropic.com/v1"
    
    async def generate_dialog(self, prompt: str, model: str = "claude-3-haiku-20240307", system_prompt: str = None) -> str:
        headers = {
            "x-api-key": self.api_key,
            "Content-Type": "application/json",
            "anthropic-version": "2023-06-01"
        }
        
        payload = {
            "model": model,
            "max_tokens": 2000,
            "messages": [{"role": "user", "content": prompt}]
        }
        
        if system_prompt:
            payload["system"] = system_prompt
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{self.base_url}/messages",
                headers=headers,
                json=payload,
                timeout=self.timeout
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise Exception(f"Anthropic API error {response.status}: {error_text}")
                
                data = await response.json()
                return data["content"][0]["text"]

class GeminiProvider(AIProvider):
    """Провайдер для Google Gemini API"""
    
    def __init__(self, api_key: str, timeout: int = 30):
        super().__init__(api_key, timeout)
        self.base_url = "https://generativelanguage.googleapis.com/v1beta"
    
    async def generate_dialog(self, prompt: str, model: str = "gemini-1.5-flash", system_prompt: str = None) -> str:
        url = f"{self.base_url}/models/{model}:generateContent?key={self.api_key}"
        
        contents = []
        if system_prompt:
            contents.append({"parts": [{"text": system_prompt}], "role": "user"})
            contents.append({"parts": [{"text": "Понял, буду следовать этим инструкциям."}], "role": "model"})
        
        contents.append({"parts": [{"text": prompt}], "role": "user"})
        
        payload = {
            "contents": contents,
            "generationConfig": {
                "temperature": 0.8,
                "maxOutputTokens": 2000
            }
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                url,
                json=payload,
                timeout=self.timeout
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise Exception(f"Gemini API error {response.status}: {error_text}")
                
                data = await response.json()
                return data["candidates"][0]["content"]["parts"][0]["text"]

class PollinationsProvider(AIProvider):
    """Провайдер для Pollinations AI"""
    
    def __init__(self, api_key: str = None, timeout: int = 30):
        super().__init__(api_key, timeout)
        self.openai_url = "https://text.pollinations.ai/openai"
        self.simple_url = "https://text.pollinations.ai/"
    
    async def generate_dialog(self, prompt: str, model: str = "openai", system_prompt: str = None) -> str:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        try:
            # Попытка через OpenAI-совместимый endpoint
            payload = {"model": model, "messages": messages}
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    self.openai_url,
                    json=payload,
                    headers=headers,
                    timeout=self.timeout
                ) as response:
                    text = await response.text()
                    try:
                        data = await response.json()
                        if "choices" in data and data["choices"]:
                            choice = data["choices"][0]
                            if "message" in choice and choice["message"].get("content"):
                                return choice["message"]["content"]
                            elif choice.get("text"):
                                return choice["text"]
                        elif data.get("response"):
                            return data["response"]
                    except:
                        pass
                    return text
        except Exception as e:
            logger.warning(f"Pollinations OpenAI endpoint failed: {e}, trying simple endpoint")
            
        # Fallback к простому GET endpoint
        encoded_prompt = urllib.parse.quote(prompt, safe='')
        url = f"{self.simple_url}{encoded_prompt}?json=true"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=self.timeout) as response:
                text = await response.text()
                try:
                    data = await response.json()
                    if isinstance(data, dict):
                        return data.get("response") or data.get("text") or str(data)
                    return str(data)
                except:
                    return text

async def get_ai_provider():
    """Получает настроенный AI провайдер из базы данных"""
    try:
        settings = await db.get_settings()
    except Exception:
        settings = {}
    
    provider_type = settings.get("ai_provider") or "pollinations"
    timeout = int(settings.get("ai_timeout") or TIMEOUT)
    
    if provider_type == "openai":
        api_key = settings.get("openai_token") or os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OpenAI API key not configured")
        return OpenAIProvider(api_key, timeout)
    
    elif provider_type == "anthropic":
        api_key = settings.get("anthropic_token") or os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            raise ValueError("Anthropic API key not configured")
        return AnthropicProvider(api_key, timeout)
    
    elif provider_type == "gemini":
        api_key = settings.get("gemini_token") or os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("Gemini API key not configured")
        return GeminiProvider(api_key, timeout)
    
    else:  # pollinations или неизвестный провайдер
        api_key = settings.get("pollinations_token") or os.getenv("POLLINATIONS_TOKEN")
        return PollinationsProvider(api_key, timeout)

async def ai_generate_dialog(num_roles: int) -> dict:
    """
    Генерирует диалог с помощью выбранного AI провайдера.
    Возвращаемая структура:
    {
        "name": str,
        "messages": [{"role": "User 1", "text": "..."}, ...],
        "num_accounts": int,
        "raw": raw_text
    }
    """
    # Подготовка prompt
    details_list = []
    if DETAILS:
        try:
            details_list = [d.strip().strip('"') for d in DETAILS if d.strip()]
        except Exception:
            details_list = []
    
    detail = random.choice(details_list) if details_list else "случайная бытовая тема"
    prompt = PROMPT_TEMPLATE.format(num=num_roles, detail=detail)
    
    # Получаем настройки из БД
    try:
        settings = await db.get_settings()
    except Exception:
        settings = {}
    
    model = settings.get("ai_model") or "gpt-4o-mini"
    system_prompt = settings.get("ai_system_prompt") or ""
    
    # Получаем AI провайдер и генерируем диалог
    provider = await get_ai_provider()
    content = await provider.generate_dialog(prompt, model, system_prompt)
    
    # Парсим результат
    lines = []
    for line in content.splitlines():
        line = line.strip()
        if not line:
            continue
        
        # Поддерживаем форматы: [User 1] text  OR User 1: text
        m = re.match(r"^\\[(?P<role>[^\\]]+)\\]\\s*(?P<text>.+)$", line)
        if not m:
            m = re.match(r"^(?P<role>User\\s*\\d+)[\\:\\-\\)]*\\s*(?P<text>.+)$", line)
        
        if m:
            role = m.group("role").strip()
            text_msg = m.group("text").strip()
            lines.append({"role": role, "text": text_msg})
    
    # Если парсинг не дал результата — автоназначение ролей
    if not lines:
        chunks = [l.strip() for l in content.splitlines() if l.strip()]
        lines = []
        for i, chunk in enumerate(chunks, start=1):
            role = f"User {((i-1) % num_roles) + 1}"
            lines.append({"role": role, "text": chunk})
    
    # Фильтруем только валидные роли User 1..num_roles
    filtered = []
    for m in lines:
        mm = re.match(r"User\\s+(\\d+)$", m["role"])
        if mm and 1 <= int(mm.group(1)) <= num_roles:
            filtered.append(m)
    
    name = f"ai_{datetime.now():%Y%m%dT%H%M%SZ}_{random.randint(1000,9999)}"
    return {
        "name": name,
        "messages": filtered,
        "num_accounts": num_roles,
        "raw": content
    }